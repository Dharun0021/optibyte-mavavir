import 'package:flutter/material.dart';
import 'package:esp/screens/add_remote_page.dart';

class ACCustomizationPage extends StatefulWidget {
  const ACCustomizationPage({super.key});

  @override
  _ACCustomizationPageState createState() => _ACCustomizationPageState();
}

class _ACCustomizationPageState extends State<ACCustomizationPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("AC Customization"),
        backgroundColor: const Color(0xFF02CCFE),
        actions: [
          PopupMenuButton<String>(
            onSelected: (value) {
              if (value == 'add_remote') {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const AddRemotePage()),
                );
              } else if (value == 'config_mode') {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text("Config Mode clicked")),
                );
              }
            },
            itemBuilder: (BuildContext context) => <PopupMenuEntry<String>>[
              const PopupMenuItem<String>(
                value: 'add_remote',
                child: Text('Add Remote'),
              ),
              const PopupMenuItem<String>(
                value: 'config_mode',
                child: Text('Config Mode'),
              ),
            ],
          )
        ],
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text("AC Customization Page"),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // Example: send power on
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text("Sending POWER_ON command")),
                );
              },
              child: const Text("Power ON"),
            ),
          ],
        ),
      ),
    );
  }
}
