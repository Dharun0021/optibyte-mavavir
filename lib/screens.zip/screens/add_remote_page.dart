import 'package:flutter/material.dart';
import 'package:esp/screens/ac_remote_page.dart';
import 'package:esp/screens/ac_customization_page.dart';
import 'package:esp/service/bluetooth_service.dart';

class AddRemotePage extends StatelessWidget {
  const AddRemotePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Add Remote"),
        backgroundColor: Colors.lightBlue,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: GridView.count(
          crossAxisCount: 2,
          crossAxisSpacing: 16,
          mainAxisSpacing: 16,
          children: [
            buildDeviceCard(context, "AC", "assets/images/ac.jpg"),
            buildDeviceCard(context, "TV", "assets/images/tv.jpg"),
            buildDeviceCard(
                context, "Set Top Box", "assets/images/settopbox.jpg"),
          ],
        ),
      ),
    );
  }

  Widget buildDeviceCard(BuildContext context, String title, String imagePath) {
    return GestureDetector(
      onTap: () {
        if (title == "AC") {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => ACRemotePage(
                bluetoothService: BluetoothService(),
              ),
            ),
          );
        } else if (title == "TV") {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const ACCustomizationPage(),
            ),
          );
        } else if (title == "Set Top Box") {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const ACCustomizationPage(),
            ),
          );
        }
      },
      child: Card(
        elevation: 4,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Expanded(child: Image.asset(imagePath, fit: BoxFit.contain)),
            const SizedBox(height: 8),
            Text(title, style: const TextStyle(fontSize: 18)),
          ],
        ),
      ),
    );
  }
}
