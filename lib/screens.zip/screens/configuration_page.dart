import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter_bluetooth_serial/flutter_bluetooth_serial.dart';
import 'bluetooth_scanner_page.dart'; // adjust to your actual file path
import 'add_remote_page.dart';       // adjust to your actual file path

class ConfigurationPage extends StatefulWidget {
  final BluetoothConnection connection;
  final BluetoothDevice device;

  const ConfigurationPage({
    super.key,
    required this.connection,
    required this.device,
  });

  @override
  State<ConfigurationPage> createState() => _ConfigurationPageState();
}

class _ConfigurationPageState extends State<ConfigurationPage> {
  final TextEditingController _commandController = TextEditingController();
  final List<String> _receivedData = [];
  late BluetoothConnection _connection;
  bool _isConnected = false;

  @override
  void initState() {
    super.initState();
    _connection = widget.connection;
    _isConnected = _connection.isConnected;

    _connection.input?.listen(_onDataReceived).onDone(() {
      if (mounted) {
        setState(() => _isConnected = false);
      }
    });
  }

  void _onDataReceived(Uint8List data) {
    final text = utf8.decode(data);
    setState(() {
      _receivedData.insert(0, text.trim());
    });
  }

  Future<void> _sendCommand() async {
    final text = _commandController.text.trim();
    if (text.isEmpty || !_isConnected) return;

    try {
      final data = utf8.encode("$text\r\n");
      _connection.output.add(Uint8List.fromList(data));
      await _connection.output.allSent;
      setState(() {
        _receivedData.insert(0, "You: $text");
        _commandController.clear();
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Failed to send: $e")),
        );
      }
    }
  }

  Future<void> _disconnectBluetooth() async {
    try {
      await _connection.close();
      if (mounted) {
        setState(() => _isConnected = false);
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => const BluetoothScannerPage()),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Failed to disconnect: $e")),
        );
      }
    }
  }

  @override
  void dispose() {
    if (_isConnected) {
      _connection.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        await _disconnectBluetooth();
        return false;
      },
      child: Scaffold(
        appBar: AppBar(
          title: Text("Config ${widget.device.name ?? "Unknown"}"),
          backgroundColor: Colors.lightBlue,
          actions: [
            IconButton(
              icon: const Icon(Icons.bluetooth_disabled),
              onPressed: _disconnectBluetooth,
              tooltip: "Disconnect Bluetooth",
            ),
            PopupMenuButton<String>(
              onSelected: (value) {
                if (value == 'add_remote') {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const AddRemotePage()),
                  );
                }
              },
              itemBuilder: (BuildContext context) {
                return [
                  const PopupMenuItem(
                    value: 'add_remote',
                    child: Text('Add Remote'),
                  ),
                ];
              },
            ),
          ],
        ),
        body: Column(
          children: [
            Container(
              color: Colors.lightBlue[50],
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  const Icon(Icons.bluetooth_connected, color: Colors.lightBlue),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      "${widget.device.name ?? "Unknown"} (${widget.device.address})",
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: _isConnected ? Colors.green : Colors.red,
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(
                      _isConnected ? "Connected" : "Disconnected",
                      style: const TextStyle(color: Colors.white),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),
            Expanded(
              child: _receivedData.isEmpty
                  ? const Center(child: Text("No data received yet."))
                  : ListView.builder(
                      reverse: true,
                      itemCount: _receivedData.length,
                      itemBuilder: (context, index) {
                        return ListTile(
                          title: Text(_receivedData[index]),
                        );
                      },
                    ),
            ),
            Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _commandController,
                      decoration: InputDecoration(
                        hintText: "Enter command...",
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  ElevatedButton(
                    onPressed: _sendCommand,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.lightBlue,
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
                    ),
                    child: const Text("Send"),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
