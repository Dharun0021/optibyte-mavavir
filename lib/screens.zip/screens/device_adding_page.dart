import 'package:flutter/material.dart';
import 'package:esp/screens/bluetooth_scanner_page.dart'; // create this page for your bluetooth scan

class DeviceAddingPage extends StatelessWidget {
  const DeviceAddingPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Add Device"),
        backgroundColor: Colors.lightBlue,
        actions: [
          IconButton(
            icon: const Icon(Icons.bluetooth, color: Colors.white),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const BluetoothScannerPage()),
              );
            },
          ),
        ],
      ),
      body: const Center(
        child: Text(
          "This is the Add Device page.\nTap the Bluetooth icon to scan.",
          style: TextStyle(fontSize: 16),
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}
