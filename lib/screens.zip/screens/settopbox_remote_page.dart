import 'package:flutter/material.dart';

class SetTopBoxRemotePage extends StatelessWidget {
  const SetTopBoxRemotePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Set Top Box Remote"),
        backgroundColor: const Color(0xFF02CCFE),
      ),
      body: Center(
        child: const Text("Set Top Box controls like menu, channels"),
      ),
    );
  }
}
