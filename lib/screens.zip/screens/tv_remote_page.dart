import 'package:flutter/material.dart';

class TVRemotePage extends StatelessWidget {
  const TVRemotePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("TV Remote"),
        backgroundColor: const Color(0xFF02CCFE),
      ),
      body: Center(
        child: const Text("TV remote controls like volume, channels"),
      ),
    );
  }
}
