import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:esp/service/bluetooth_service.dart';

class ACRemotePage extends StatefulWidget {
  final BluetoothService bluetoothService;
  const ACRemotePage({super.key, required this.bluetoothService});

  @override
  State<ACRemotePage> createState() => _ACRemotePageState();
}

class _ACRemotePageState extends State<ACRemotePage> with SingleTickerProviderStateMixin {
  bool isConfigMode = false;
  int currentTemp = 24;
  late AnimationController _controller;
  late Animation<double> _animation;
  double _animatedTemp = 24;

  @override
  void initState() {
    super.initState();
    widget.bluetoothService.onDataReceived = _handleBluetoothData;

    _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 500));
    _animation = Tween<double>(begin: currentTemp.toDouble(), end: currentTemp.toDouble()).animate(_controller)
      ..addListener(() {
        setState(() => _animatedTemp = _animation.value);
      });
  }

  void _handleBluetoothData(String data) {
    data = data.trim();
    if (data.contains("_SIGNAL_RECEIVED")) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("$data from ESP32")),
      );
    }
  }

  void _sendOrWait(String normalCmd, String waitCmd) async {
    HapticFeedback.lightImpact();
    if (isConfigMode) {
      widget.bluetoothService.sendCommand(waitCmd);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Waiting for $waitCmd from ESP32...")),
      );
    } else {
      widget.bluetoothService.sendCommand(normalCmd);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("$normalCmd sent to ESP32")),
      );
    }
  }

  void _changeTemp(bool increase) {
    final oldTemp = currentTemp.toDouble();
    setState(() {
      if (increase && currentTemp < 30) currentTemp++;
      if (!increase && currentTemp > 16) currentTemp--;
    });
    _animation = Tween<double>(begin: oldTemp, end: currentTemp.toDouble()).animate(_controller);
    _controller.forward(from: 0);
    HapticFeedback.selectionClick();

    _sendOrWait("SET_TEMP_$currentTemp", "WAIT_FOR_TEMP_${currentTemp}_SIGNAL");
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Widget _scaleTap({required Widget child, required VoidCallback onTap}) {
    return GestureDetector(
      onTapDown: (_) => HapticFeedback.lightImpact(),
      onTap: onTap,
      child: AnimatedScale(
        scale: 1.0,
        duration: const Duration(milliseconds: 100),
        child: child,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("LG"),
        backgroundColor: Colors.lightBlue,
        actions: [
          IconButton(
            icon: const Icon(Icons.power_settings_new),
            onPressed: () => _sendOrWait("POWER_TOGGLE", "WAIT_FOR_POWER_SIGNAL"),
          ),
          PopupMenuButton<String>(
            onSelected: (value) {
              if (value == 'config_mode') {
                setState(() => isConfigMode = true);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text("Config Mode activated")),
                );
              }
            },
            itemBuilder: (_) => [
              const PopupMenuItem(
                value: 'config_mode',
                child: Text('Config Mode'),
              ),
            ],
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            _buildTempControls(),
            const SizedBox(height: 20),
            _buildGridButtons(),
          ],
        ),
      ),
    );
  }

  Widget _buildTempControls() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _scaleTap(
          onTap: () => _changeTemp(false),
          child: _roundButton("-", Colors.lightBlue),
        ),
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 20),
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
          decoration: BoxDecoration(
            color: Colors.lightBlue.withOpacity(0.2),
            borderRadius: BorderRadius.circular(12),
          ),
          child: AnimatedBuilder(
            animation: _animation,
            builder: (context, child) => Text(
              "${_animatedTemp.toStringAsFixed(0)}°C",
              style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: Colors.blue),
            ),
          ),
        ),
        _scaleTap(
          onTap: () => _changeTemp(true),
          child: _roundButton("+", Colors.lightBlue),
        ),
      ],
    );
  }

  Widget _roundButton(String label, Color color) {
    return ElevatedButton(
      onPressed: () {}, // stays here for animation
      style: ElevatedButton.styleFrom(
        shape: const CircleBorder(),
        backgroundColor: color.withOpacity(0.2),
        padding: const EdgeInsets.all(20),
      ),
      child: Text(label, style: TextStyle(fontSize: 24, color: color)),
    );
  }

  Widget _buildGridButtons() {
    return Expanded(
      child: GridView.count(
        crossAxisCount: 3,
        mainAxisSpacing: 16,
        crossAxisSpacing: 16,
        children: [
          _scaleTap(
            child: _iconButton("Cool Mode", Icons.ac_unit, Colors.blue),
            onTap: () => _sendOrWait("SET_MODE_COOL", "WAIT_FOR_COOL_SIGNAL"),
          ),
          _scaleTap(
            child: _iconButton("Heat Mode", Icons.whatshot, Colors.red),
            onTap: () => _sendOrWait("SET_MODE_HEAT", "WAIT_FOR_HEAT_SIGNAL"),
          ),
          _scaleTap(
            child: _iconButton("Fan Mode", Icons.toys, Colors.green),
            onTap: () => _sendOrWait("SET_MODE_FAN", "WAIT_FOR_FAN_SIGNAL"),
          ),
          _scaleTap(
            child: _iconButton("Fan Low", Icons.filter_1, Colors.green.shade700),
            onTap: () => _sendOrWait("SET_FAN_LOW", "WAIT_FOR_FAN_LOW_SIGNAL"),
          ),
          _scaleTap(
            child: _iconButton("Fan Med", Icons.filter_2, Colors.green.shade700),
            onTap: () => _sendOrWait("SET_FAN_MED", "WAIT_FOR_FAN_MED_SIGNAL"),
          ),
          _scaleTap(
            child: _iconButton("Fan High", Icons.filter_3, Colors.green.shade700),
            onTap: () => _sendOrWait("SET_FAN_HIGH", "WAIT_FOR_FAN_HIGH_SIGNAL"),
          ),
          _scaleTap(
            child: _iconButton("Swing On", Icons.swap_vert, Colors.orange),
            onTap: () => _sendOrWait("SWING_ON", "WAIT_FOR_SWING_ON_SIGNAL"),
          ),
          _scaleTap(
            child: _iconButton("Swing Off", Icons.height, Colors.orange),
            onTap: () => _sendOrWait("SWING_OFF", "WAIT_FOR_SWING_OFF_SIGNAL"),
          ),
          _scaleTap(
            child: _iconButton("Timer", Icons.timer, Colors.purple),
            onTap: () => _sendOrWait("SET_TIMER", "WAIT_FOR_TIMER_SIGNAL"),
          ),
        ],
      ),
    );
  }

  Widget _iconButton(String label, IconData icon, Color color) {
    return ElevatedButton(
      onPressed: () {},
      style: ElevatedButton.styleFrom(
        backgroundColor: color.withOpacity(0.1),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        padding: const EdgeInsets.symmetric(vertical: 12),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: color),
          const SizedBox(height: 8),
          Text(label, textAlign: TextAlign.center, style: TextStyle(color: color)),
        ],
      ),
    );
  }
}
